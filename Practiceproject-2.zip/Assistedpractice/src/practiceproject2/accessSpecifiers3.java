//using protected access specifiers
package practiceproject2;


public class accessSpecifiers3 {

	protected void display() 
    { 
        System.out.println("This is protected access specifier"); 
    } 

  public static void main(String[] args) {
		accessSpecifiers3 obj = new accessSpecifiers3 ();   
	       obj.display();  
	}

}






