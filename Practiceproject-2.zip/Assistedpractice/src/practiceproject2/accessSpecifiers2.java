package practiceproject2;

//2. using private access specifiers
class priaccessspecifier 
{ 
} 

public class accessSpecifiers2 {

	public static void main(String[] args) {
		//private
		System.out.println("Private Access Specifier");

	}
}
