package com.ecommerce;

import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Set;
import java.util.Map;

public class EProduct {
    private long ID;
    private String name;
    private BigDecimal price;
    private Date dateAdded;
    private List<Color> colors;          // Assuming a list of associated colors
    private Set<OS> os;                  // Assuming a set of associated operating systems
    @SuppressWarnings("rawtypes")
	private Map finance;                 // Assuming a map for financial details
    private List<ScreenSizes> screenSizes; // Assuming a list of associated screen sizes

    public EProduct() {
        // Default constructor required by Hibernate
    }

    public EProduct(String name, BigDecimal price, Date dateAdded,
                    List<Color> colors, Set<OS> os, @SuppressWarnings("rawtypes") Map finance, List<ScreenSizes> screenSizes) {
        this.name = name;
        this.price = price;
        this.dateAdded = dateAdded;
        this.colors = colors;
        this.os = os;
        this.finance = finance;
        this.screenSizes = screenSizes;
    }

    // Getter and Setter methods for ID, name, price, dateAdded, colors, os, finance, and screenSizes
    public long getID() {
        return ID;
    }

    public void setID(long ID) {
        this.ID = ID;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public Date getDateAdded() {
        return dateAdded;
    }

    public void setDateAdded(Date dateAdded) {
        this.dateAdded = dateAdded;
    }

    public List<Color> getColors() {
        return colors;
    }

    public void setColors(List<Color> colors) {
        this.colors = colors;
    }

    public Set<OS> getOs() {
        return os;
    }

    public void setOs(Set<OS> os) {
        this.os = os;
    }

    @SuppressWarnings("rawtypes")
	public Map getFinance() {
        return finance;
    }

    public void setFinance(@SuppressWarnings("rawtypes") Map finance) {
        this.finance = finance;
    }

    public List<ScreenSizes> getScreenSizes() {
        return screenSizes;
    }

    public void setScreenSizes(List<ScreenSizes> screenSizes) {
        this.screenSizes = screenSizes;
    }

    @Override
    public String toString() {
        return "EProduct [ID=" + ID + ", name=" + name + ", price=" + price +
               ", dateAdded=" + dateAdded + ", colors=" + colors +
               ", os=" + os + ", finance=" + finance + ", screenSizes=" + screenSizes + "]";
    }
}
