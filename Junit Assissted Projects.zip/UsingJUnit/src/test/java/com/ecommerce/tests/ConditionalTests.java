package com.ecommerce.tests;

import org.junit.jupiter.api.*;

public class ConditionalTests {

    @Test
    public void runOnWindows() {
        System.out.println("This runs on Windows");
    }

    @Test
    public void runOnLinux() {
        System.out.println("This runs on Linux");
    }

    @Test
    void mightNotBeExecuted() {
        System.out.println("This may or not execute ");
    }
}
