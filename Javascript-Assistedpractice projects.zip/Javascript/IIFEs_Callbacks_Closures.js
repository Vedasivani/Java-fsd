//IIFE and Closure
const empId = (function() {
    let count = 0;
    return function() {
      ++count;
      return `emp${count}`;
    };
  })();
  
  console.log("New Emplyee IDs are listed here");
  console.log("Devi: "+empId()); 
  console.log("prameela: "+empId()); 
  console.log("Manasa: "+empId());
   

  //Callbacks
  console.log("\n"); //to start the output from the neext line
  function fullName(firstName, lastName, callback){
    console.log("My name is " + firstName + " " + lastName);
    callback(lastName);
  }
  
  var greeting = function(ln){
    console.log('Welcome ' + ln);
  };
  
  fullName("Devi", "Naiyer", greeting);
  console.log("\n");
  fullName("Prameela", "pandey", greeting);
  console.log("\n");
  fullName("Manasa", "Reddy", greeting);
  
