package practiceproject7;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.List;

public class TextModificationProgram {
    public static void main(String[] args) {
        // Specify the file path
        String filePath = "C:\\Path\\To\\Your\\File.txt";

        try {
            // Read all lines from the file into a List
            List<String> lines = Files.readAllLines(Paths.get(filePath));

            // Update the content (replace "World" with "Universe")
            lines.replaceAll(line -> line.replace("World", "Universe"));

            // Write the updated content back to the file
            Files.write(Paths.get(filePath), lines, StandardOpenOption.WRITE, StandardOpenOption.TRUNCATE_EXISTING);

            System.out.println("File updated successfully.");
        } catch (IOException e) {
            System.out.println("An error occurred while updating the file.");
            e.printStackTrace();
        }
    }
}

	
