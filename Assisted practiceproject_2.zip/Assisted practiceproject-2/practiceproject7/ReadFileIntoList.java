package practiceproject7;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.List;

public class ReadFileIntoList {
    public static void main(String[] args) {
        // Specify the file path
        String filePath = "C:\\Path\\To\\Your\\File5.txt";

        try {
            // Read all lines from the file into a List
            List<String> lines = Files.readAllLines(Paths.get(filePath));

            // Check if the file is empty
            if (lines.isEmpty()) {
                System.out.println("File is empty.");
            } else {
                // Print the contents of the list
                System.out.println("File contents:");
                for (String line : lines) {
                    System.out.println(line);
                }
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
            e.printStackTrace();
        }
    }
}