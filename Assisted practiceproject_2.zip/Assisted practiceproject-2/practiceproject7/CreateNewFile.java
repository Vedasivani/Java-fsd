package practiceproject7;

import java.io.File;
import java.io.IOException;

public class CreateNewFile {
    public static void main(String[] args) {
        // Specify the file path
        String filePath = "C:\\Path\\To\\Your\\File5.txt";

        try {
            // Create a File object
            File file = new File(filePath);

            // Ensure the directory structure exists
            file.getParentFile().mkdirs();

            // Create the file
            if (file.createNewFile()) {
                System.out.println("File is created successfully!");
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred while creating the file.");
            e.printStackTrace();
        }
    }
}