package com.ecommerce.controller;


import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import com.ecommerce.beans.CustomEventPublisher;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

@Controller
public class MainController {
	
	@GetMapping("/customevent")
	public String customEvent(ModelMap map) {
		String confFile = "main-servlet.xml";
		 @SuppressWarnings("resource")
		ApplicationContext context = new ClassPathXmlApplicationContext(confFile);
         CustomEventPublisher cvp =
                 (CustomEventPublisher) context.getBean("customEventPublisher");
              
          cvp.publish();  
          cvp.publish();
         return "customevent";
     }
    
}
